#!/usr/bin/env bash
set -euo pipefail

npm install --omit=dev --include=optional --no-fund --no-audit
npx prisma generate
if [ "${RUN_PRISMA_MIGRATIONS:-false}" = "true" ]; then
  npm run db:deploy
fi
exec npm start
