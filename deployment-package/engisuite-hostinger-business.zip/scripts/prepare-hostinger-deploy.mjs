import { randomBytes } from 'node:crypto';
import { execSync, execFileSync } from 'node:child_process';
import { cpSync, existsSync, mkdirSync, readFileSync, rmSync, writeFileSync, chmodSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const rootDir = resolve(__dirname, '..');
const outputDir = join(rootDir, 'deployment-package', 'hostinger-business');
const archivePath = join(rootDir, 'deployment-package', 'engisuite-hostinger-business.zip');

const shouldBuild = process.argv.includes('--build');
const defaultDomain = 'https://engisuite.m2y.net';
const productionPort = process.env.HOSTINGER_PORT || process.env.PORT || '8000';
const hostingerDatabaseUrl = process.env.HOSTINGER_DATABASE_URL || '';
const frontendUrl = process.env.HOSTINGER_FRONTEND_URL || defaultDomain;
const apiUrl = process.env.HOSTINGER_API_URL || defaultDomain;
const corsOrigins = process.env.HOSTINGER_CORS_ALLOW_ORIGINS || frontendUrl;
const jwtSecret = process.env.HOSTINGER_JWT_SECRET || randomBytes(32).toString('hex');
const sessionSecret = process.env.HOSTINGER_SESSION_SECRET || randomBytes(32).toString('hex');

const requiredPaths = [
  join(rootDir, 'dist'),
  join(rootDir, 'frontend-react', 'dist'),
  join(rootDir, 'prisma'),
  join(rootDir, 'Databases'),
  join(rootDir, 'package.json'),
  join(rootDir, 'package-lock.json'),
  join(rootDir, 'ecosystem.config.cjs'),
  join(rootDir, '.env.example'),
  join(rootDir, 'server.js'),
  join(rootDir, 'scripts'),
];

function assertRequirements() {
  const missing = requiredPaths.filter((path) => !existsSync(path));
  if (missing.length > 0) {
    throw new Error(`Missing required paths:\n${missing.join('\n')}`);
  }
}

function runBuild() {
  console.log('Building server and frontend...');
  execSync('npm run build', { cwd: rootDir, stdio: 'inherit' });
}

function createFlatArchive() {
  execFileSync(
    'python3',
    [
      '-c',
      [
        'from pathlib import Path',
        'import zipfile',
        `root = Path(r"""${outputDir}""")`,
        `out = Path(r"""${archivePath}""")`,
        'if out.exists():',
        '    out.unlink()',
        'with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zf:',
        '    for p in root.rglob("*"):',
        '        zf.write(p, p.relative_to(root).as_posix())',
        'print(out)',
      ].join('\n'),
    ],
    { stdio: 'inherit' }
  );
}

function copyIntoPackage() {
  if (existsSync(outputDir)) {
    rmSync(outputDir, { recursive: true, force: true });
  }

  mkdirSync(outputDir, { recursive: true });

  cpSync(join(rootDir, 'dist'), join(outputDir, 'dist'), { recursive: true });
  cpSync(join(rootDir, 'frontend-react', 'dist'), join(outputDir, 'frontend-react', 'dist'), { recursive: true });
  cpSync(join(rootDir, 'prisma'), join(outputDir, 'prisma'), {
    recursive: true,
    filter: (source) => !source.includes('migrations'),
  });
  cpSync(join(rootDir, 'Databases'), join(outputDir, 'Databases'), { recursive: true });

  const packageJson = JSON.parse(readFileSync(join(rootDir, 'package.json'), 'utf8'));
  packageJson.main = 'server.js';
  packageJson.scripts = {
    ...packageJson.scripts,
    build: "node -e \"console.log('Build already bundled for Hostinger shared hosting')\"",
    buildcss: "node -e \"console.log('No separate CSS build step required')\"",
    'build:css': "node -e \"console.log('No separate CSS build step required')\"",
    start: 'node server.js',
    'hostinger:start': 'node server.js',
  };

  writeFileSync(join(outputDir, 'package.json'), JSON.stringify(packageJson, null, 2) + '\n');
  cpSync(join(rootDir, 'package-lock.json'), join(outputDir, 'package-lock.json'));
  cpSync(join(rootDir, 'ecosystem.config.cjs'), join(outputDir, 'ecosystem.config.cjs'));
  cpSync(join(rootDir, '.env.example'), join(outputDir, '.env.example'));
  cpSync(join(rootDir, 'server.js'), join(outputDir, 'server.js'));
  cpSync(join(rootDir, 'scripts'), join(outputDir, 'scripts'), { recursive: true });

  mkdirSync(join(outputDir, 'logs'), { recursive: true });

  const productionEnvLines = [
    'NODE_ENV=production',
    `PORT=${productionPort}`,
    'DATABASE_URL="mysql://u449943183_EngSuitDatabas:YOUR_DB_PASSWORD@localhost:3306/u449943183_EngSuiteDB"',
    'JWT_SECRET=change-me-in-production',
    'SESSION_SECRET=change-me-in-production',
    'AUTO_DB_PUSH_ON_START=true',
    'RUN_PRISMA_MIGRATIONS=false',
    'SKIP_DB_SYNC=false',
    'WORKFLOW_DATABASE_URL=./Databases/workflows.db',
    'COURSES_DATABASE_URL=./Databases/engmastery.db',
    `FRONTEND_URL=${frontendUrl}`,
    `API_URL=${apiUrl}`,
    `CORS_ALLOW_ORIGINS=${corsOrigins}`,
  ];

  writeFileSync(join(outputDir, '.env.production.example'), productionEnvLines.join('\n') + '\n');

  const resolvedDatabaseUrl = hostingerDatabaseUrl || '';
  const readyEnvLines = [
    'NODE_ENV=production',
    `PORT=${productionPort}`,
    `DATABASE_URL="${resolvedDatabaseUrl}"`,
    `HOSTINGER_DATABASE_URL="${resolvedDatabaseUrl}"`,
    `JWT_SECRET=${jwtSecret}`,
    `SESSION_SECRET=${sessionSecret}`,
    'AUTO_DB_PUSH_ON_START=false',
    'RUN_PRISMA_MIGRATIONS=false',
    'SKIP_DB_SYNC=false',
    'WORKFLOW_DATABASE_URL=./Databases/workflows.db',
    'COURSES_DATABASE_URL=./Databases/engmastery.db',
    `FRONTEND_URL=${frontendUrl}`,
    `API_URL=${apiUrl}`,
    `CORS_ALLOW_ORIGINS=${corsOrigins}`,
  ];

  writeFileSync(join(outputDir, '.env'), readyEnvLines.join('\n') + '\n');

  const startScript = join(outputDir, 'start-production.sh');
  writeFileSync(
    startScript,
    [
      '#!/usr/bin/env bash',
      'set -euo pipefail',
      '',
      'npm install --omit=dev --include=optional --no-fund --no-audit',
      'npx prisma generate',
      'if [ "${RUN_PRISMA_MIGRATIONS:-false}" = "true" ]; then',
      '  npm run db:deploy',
      'fi',
      'exec npm start',
    ].join('\n') + '\n'
  );

  try {
    chmodSync(startScript, 0o755);
  } catch {
    // Ignore on platforms that do not support chmod as expected.
  }

  writeFileSync(
    join(outputDir, 'DEPLOY_HOSTINGER_BUSINESS.md'),
    [
      '# Hostinger Business Quick Deploy',
      '',
      'This package is prepared for Hostinger shared Node.js hosting — no VPS or PM2 setup required.',
      '',
      '1. Upload a flat ZIP so the files are directly at the archive root, then extract it into your Hostinger Node.js app directory.',
      '2. Set the startup file/command in hPanel to `server.js`, `npm start`, or `npm run hostinger:start`.',
      '3. Add your `.env` values in hPanel or upload a ready `.env` file.',
      '4. Restart the application from hPanel.',
      '5. Verify the site root `/` and health endpoint `/health`.',
      '',
      '> The frontend now uses same-origin `/api` calls by default, which is ideal for Hostinger shared hosting.',
    ].join('\n') + '\n'
  );
}

try {
  if (shouldBuild) {
    runBuild();
  }

  assertRequirements();
  copyIntoPackage();
  createFlatArchive();

  console.log('Hostinger deployment package ready at:');
  console.log(outputDir);
  console.log('Hostinger deployment ZIP ready at:');
  console.log(archivePath);
} catch (error) {
  console.error('Failed to prepare Hostinger package:', error.message);
  process.exit(1);
}
