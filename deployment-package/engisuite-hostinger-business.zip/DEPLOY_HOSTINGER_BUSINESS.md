# Hostinger Business Quick Deploy

This package is prepared for Hostinger shared Node.js hosting — no VPS or PM2 setup required.

1. Upload a flat ZIP so the files are directly at the archive root, then extract it into your Hostinger Node.js app directory.
2. Set the startup file/command in hPanel to `server.js`, `npm start`, or `npm run hostinger:start`.
3. Add your `.env` values in hPanel or upload a ready `.env` file.
4. Restart the application from hPanel.
5. Verify the site root `/` and health endpoint `/health`.

> The frontend now uses same-origin `/api` calls by default, which is ideal for Hostinger shared hosting.
