import 'dotenv/config';

const isProduction = process.env.NODE_ENV === 'production';

const resolvedPrimaryDatabaseUrl = isProduction
  ? process.env.HOSTINGER_DATABASE_URL || process.env.DATABASE_URL
  : process.env.LOCAL_DATABASE_URL || process.env.DATABASE_URL;

if (resolvedPrimaryDatabaseUrl) {
  process.env.DATABASE_URL = resolvedPrimaryDatabaseUrl;
}

process.env.WORKFLOW_DATABASE_URL = isProduction
  ? process.env.HOSTINGER_WORKFLOW_DATABASE_URL || process.env.WORKFLOW_DATABASE_URL || process.env.WORKFLOWS_DB_PATH || './Databases/workflows.db'
  : process.env.LOCAL_WORKFLOW_DATABASE_URL || process.env.WORKFLOW_DATABASE_URL || process.env.WORKFLOWS_DB_PATH || './Databases/workflows.db';

process.env.COURSES_DATABASE_URL = isProduction
  ? process.env.HOSTINGER_COURSES_DATABASE_URL || process.env.COURSES_DATABASE_URL || process.env.COURSES_DB_PATH || './Databases/engmastery.db'
  : process.env.LOCAL_COURSES_DATABASE_URL || process.env.COURSES_DATABASE_URL || process.env.COURSES_DB_PATH || './Databases/engmastery.db';

async function bootstrap() {
  try {
    await import('./scripts/prepare-db.mjs');
    await import('./dist/server.js');
  } catch (error) {
    console.error('[server bootstrap] Failed to start application:', error);
    process.exit(1);
  }
}

bootstrap();
