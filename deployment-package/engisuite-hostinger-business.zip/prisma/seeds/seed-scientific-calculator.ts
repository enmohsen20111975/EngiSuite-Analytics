/**
 * Seed script for new Scientific Calculator categories and equations
 * Run with: npx ts-node prisma/seeds/seed-scientific-calculator.ts
 */

import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  console.log('🔬 Seeding Scientific Calculator equations...');

  // ============================================
  // 1. Create new equation categories
  // ============================================
  
  const calculusCategory = await prisma.equationCategory.upsert({
    where: { slug: 'calculus' },
    update: {},
    create: {
      name: 'Calculus',
      slug: 'calculus',
      description: 'Derivatives, integrals, limits and series',
      icon: 'Sigma',
      color: '#FF6B6B',
      sortOrder: 10,
    },
  });
  console.log('✓ Created Calculus category');

  const statisticsCategory = await prisma.equationCategory.upsert({
    where: { slug: 'statistics' },
    update: {},
    create: {
      name: 'Statistics',
      slug: 'statistics',
      description: 'Probability, distributions, and hypothesis testing',
      icon: 'BarChart3',
      color: '#4ECDC4',
      sortOrder: 11,
    },
  });
  console.log('✓ Created Statistics category');

  const algebraCategory = await prisma.equationCategory.upsert({
    where: { slug: 'algebra' },
    update: {},
    create: {
      name: 'Algebra',
      slug: 'algebra',
      description: 'Equation solving and matrix operations',
      icon: 'Brackets',
      color: '#95E1D3',
      sortOrder: 12,
    },
  });
  console.log('✓ Created Algebra category');

  // ============================================
  // 2. Create Calculus Equations
  // ============================================

  const derivativeEquation = await prisma.equation.upsert({
    where: { slug: 'calculus_power_rule' },
    update: {},
    create: {
      categoryId: calculusCategory.id,
      name: 'Power Rule Derivative',
      slug: 'calculus_power_rule',
      description: 'Calculate the derivative of x^n using the power rule',
      formula: 'f(x) = x^n → f\'(x) = n*x^(n-1)',
      variables: JSON.stringify(['x', 'n']),
      tags: JSON.stringify(['calculus', 'derivative', 'power-rule']),
      difficulty: 'intermediate',
      inputs: {
        create: [
          {
            name: 'Power (n)',
            slug: 'power',
            type: 'number',
            defaultValue: '2',
            description: 'The exponent in x^n',
          },
          {
            name: 'Variable (x)',
            slug: 'variable_x',
            type: 'number',
            defaultValue: '1',
            description: 'The value at which to evaluate the derivative',
          },
        ],
      },
      outputs: {
        create: [
          {
            name: 'Derivative f\'(x)',
            slug: 'derivative_result',
            type: 'number',
            formula: 'n*(x^(n-1))',
            precision: 6,
          },
        ],
      },
    },
  });
  console.log('✓ Created Power Rule Derivative equation');

  const integralEquation = await prisma.equation.upsert({
    where: { slug: 'calculus_basic_integral' },
    update: {},
    create: {
      categoryId: calculusCategory.id,
      name: 'Basic Integral',
      slug: 'calculus_basic_integral',
      description: 'Calculate the integral of x^n',
      formula: '∫ x^n dx = (x^(n+1))/(n+1) + C',
      variables: JSON.stringify(['x', 'n']),
      tags: JSON.stringify(['calculus', 'integral', 'antiderivative']),
      difficulty: 'intermediate',
      inputs: {
        create: [
          {
            name: 'Power (n)',
            slug: 'power',
            type: 'number',
            defaultValue: '2',
          },
          {
            name: 'Upper Limit',
            slug: 'upper_limit',
            type: 'number',
            defaultValue: '2',
            description: 'Upper bound for definite integral',
          },
          {
            name: 'Lower Limit',
            slug: 'lower_limit',
            type: 'number',
            defaultValue: '0',
            description: 'Lower bound for definite integral',
          },
        ],
      },
      outputs: {
        create: [
          {
            name: 'Definite Integral Result',
            slug: 'integral_result',
            type: 'number',
            precision: 6,
          },
        ],
      },
    },
  });
  console.log('✓ Created Basic Integral equation');

  // ============================================
  // 3. Create Statistics Equations
  // ============================================

  const descriptiveStatsEquation = await prisma.equation.upsert({
    where: { slug: 'statistics_descriptive' },
    update: {},
    create: {
      categoryId: statisticsCategory.id,
      name: 'Descriptive Statistics',
      slug: 'statistics_descriptive',
      description: 'Calculate mean, median, mode, standard deviation, and variance',
      formula: 'Mean = Σx/n, Variance = Σ(x-μ)²/n, StDev = √Variance',
      variables: JSON.stringify(['x', 'n']),
      tags: JSON.stringify(['statistics', 'descriptive', 'mean', 'variance']),
      difficulty: 'beginner',
      inputs: {
        create: [
          {
            name: 'Data Values',
            slug: 'data_values',
            type: 'array',
            description: 'Comma-separated list of numbers',
          },
        ],
      },
      outputs: {
        create: [
          { name: 'Mean', slug: 'mean', type: 'number', precision: 4 },
          { name: 'Median', slug: 'median', type: 'number', precision: 4 },
          { name: 'Mode', slug: 'mode', type: 'number', precision: 4 },
          { name: 'Standard Deviation', slug: 'stdev', type: 'number', precision: 4 },
          { name: 'Variance', slug: 'variance', type: 'number', precision: 4 },
          { name: 'Min', slug: 'min', type: 'number', precision: 4 },
          { name: 'Max', slug: 'max', type: 'number', precision: 4 },
        ],
      },
    },
  });
  console.log('✓ Created Descriptive Statistics equation');

  const normalDistribution = await prisma.equation.upsert({
    where: { slug: 'statistics_normal_distribution' },
    update: {},
    create: {
      categoryId: statisticsCategory.id,
      name: 'Normal Distribution (Z-Score)',
      slug: 'statistics_normal_distribution',
      description: 'Calculate z-score and probability in normal distribution',
      formula: 'z = (x - μ) / σ',
      variables: JSON.stringify(['x', 'μ', 'σ']),
      tags: JSON.stringify(['statistics', 'normal-distribution', 'z-score']),
      difficulty: 'intermediate',
      inputs: {
        create: [
          {
            name: 'Value (x)',
            slug: 'value_x',
            type: 'number',
            description: 'The value to standardize',
          },
          {
            name: 'Mean (μ)',
            slug: 'mean',
            type: 'number',
            defaultValue: '0',
          },
          {
            name: 'Standard Deviation (σ)',
            slug: 'stdev',
            type: 'number',
            defaultValue: '1',
            min: 0.1,
          },
        ],
      },
      outputs: {
        create: [
          {
            name: 'Z-Score',
            slug: 'z_score',
            type: 'number',
            precision: 4,
          },
          {
            name: 'Probability (P(Z ≤ z))',
            slug: 'probability',
            type: 'number',
            precision: 6,
          },
        ],
      },
    },
  });
  console.log('✓ Created Normal Distribution equation');

  // ============================================
  // 4. Create Algebra Equations
  // ============================================

  const linearEquation = await prisma.equation.upsert({
    where: { slug: 'algebra_linear_equation' },
    update: {},
    create: {
      categoryId: algebraCategory.id,
      name: 'Linear Equation Solver',
      slug: 'algebra_linear_equation',
      description: 'Solve linear equation: ax + b = 0',
      formula: 'ax + b = 0 → x = -b/a',
      variables: JSON.stringify(['a', 'b', 'x']),
      tags: JSON.stringify(['algebra', 'linear', 'equation-solver']),
      difficulty: 'beginner',
      inputs: {
        create: [
          {
            name: 'Coefficient (a)',
            slug: 'coefficient_a',
            type: 'number',
            defaultValue: '2',
            description: 'Coefficient of x',
          },
          {
            name: 'Constant (b)',
            slug: 'constant_b',
            type: 'number',
            defaultValue: '5',
            description: 'Constant term',
          },
        ],
      },
      outputs: {
        create: [
          {
            name: 'Solution (x)',
            slug: 'solution_x',
            type: 'number',
            formula: '-b/a',
            precision: 6,
          },
        ],
      },
    },
  });
  console.log('✓ Created Linear Equation Solver');

  const quadraticEquation = await prisma.equation.upsert({
    where: { slug: 'algebra_quadratic_equation' },
    update: {},
    create: {
      categoryId: algebraCategory.id,
      name: 'Quadratic Equation Solver',
      slug: 'algebra_quadratic_equation',
      description: 'Solve quadratic equation: ax² + bx + c = 0',
      formula: 'ax² + bx + c = 0 → x = (-b ± √Δ) / 2a, Δ = b² - 4ac',
      variables: JSON.stringify(['a', 'b', 'c', 'x']),
      tags: JSON.stringify(['algebra', 'quadratic', 'equation-solver', 'discriminant']),
      difficulty: 'intermediate',
      inputs: {
        create: [
          {
            name: 'Coefficient a (x² term)',
            slug: 'coefficient_a',
            type: 'number',
            defaultValue: '1',
          },
          {
            name: 'Coefficient b (x term)',
            slug: 'coefficient_b',
            type: 'number',
            defaultValue: '0',
          },
          {
            name: 'Coefficient c (constant)',
            slug: 'coefficient_c',
            type: 'number',
            defaultValue: '-4',
          },
        ],
      },
      outputs: {
        create: [
          {
            name: 'Discriminant (Δ)',
            slug: 'discriminant',
            type: 'number',
            formula: 'b² - 4ac',
            precision: 6,
          },
          {
            name: 'Solution 1 (x₁)',
            slug: 'solution_x1',
            type: 'number',
            precision: 6,
          },
          {
            name: 'Solution 2 (x₂)',
            slug: 'solution_x2',
            type: 'number',
            precision: 6,
          },
        ],
      },
    },
  });
  console.log('✓ Created Quadratic Equation Solver');

  const systemOfEquations = await prisma.equation.upsert({
    where: { slug: 'algebra_system_2x2' },
    update: {},
    create: {
      categoryId: algebraCategory.id,
      name: 'System of 2x2 Linear Equations',
      slug: 'algebra_system_2x2',
      description: 'Solve system of two linear equations with two variables using Cramer\'s rule',
      formula: 'a₁x + b₁y = c₁ | a₂x + b₂y = c₂',
      variables: JSON.stringify(['a₁', 'b₁', 'c₁', 'a₂', 'b₂', 'c₂', 'x', 'y']),
      tags: JSON.stringify(['algebra', 'system', 'linear-system', 'cramers-rule']),
      difficulty: 'intermediate',
      inputs: {
        create: [
          {
            name: 'a₁ (Equation 1, x coefficient)',
            slug: 'a1',
            type: 'number',
            defaultValue: '2',
          },
          {
            name: 'b₁ (Equation 1, y coefficient)',
            slug: 'b1',
            type: 'number',
            defaultValue: '1',
          },
          {
            name: 'c₁ (Equation 1, constant)',
            slug: 'c1',
            type: 'number',
            defaultValue: '8',
          },
          {
            name: 'a₂ (Equation 2, x coefficient)',
            slug: 'a2',
            type: 'number',
            defaultValue: '1',
          },
          {
            name: 'b₂ (Equation 2, y coefficient)',
            slug: 'b2',
            type: 'number',
            defaultValue: '3',
          },
          {
            name: 'c₂ (Equation 2, constant)',
            slug: 'c2',
            type: 'number',
            defaultValue: '9',
          },
        ],
      },
      outputs: {
        create: [
          {
            name: 'Determinant (D)',
            slug: 'determinant',
            type: 'number',
            precision: 6,
          },
          {
            name: 'Solution x',
            slug: 'solution_x',
            type: 'number',
            precision: 6,
          },
          {
            name: 'Solution y',
            slug: 'solution_y',
            type: 'number',
            precision: 6,
          },
        ],
      },
    },
  });
  console.log('✓ Created System of 2x2 Equations');

  console.log('\n✅ Scientific Calculator seeding complete!');
  console.log(`- Calculus: ${calculusCategory.id}`);
  console.log(`- Statistics: ${statisticsCategory.id}`);
  console.log(`- Algebra: ${algebraCategory.id}`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
